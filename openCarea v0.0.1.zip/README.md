# An open source client area, free and simple to install and use (still under development)

<p>A client area with registration control and simple to use and modify, using simple languages such as: HTML, CSS, JavaScript and PHP</p>

# How to install?
<ol>
  <li>*Download the complete package and extract it on your server / website</li>
  <li>*Access the clientInstall.php file (Exem: mydomain.com/clientInstall.php)</li>
  <li>*You will see this screen:<br><img src="https://i.ibb.co/cxXBrDq/01c.png"></li>
  <li>*Create a new mysql database</li>
  <li>*Enter the requested information and click send</li>
  <li>*You will be directed to a new page with the message: "Database successfully configured!". With a button: "Register an administrator", click the button.(If the message is: "Failed to connect to the database, check the information!", Click the "Back to configuration" button, check the information and try again.)</li>
  <li>*After clicking on "Register an administrator" you will be redirected to the page: "Register an administrator account":<br><img src="https://i.ibb.co/rM9R0B1/02c.png"></li>
  <li>*Enter the requested information and click send.</li>
  <li>*Finally you will be directed to the login page, enter the information used in the adm account registration, and click on send.</li>
</ol>










